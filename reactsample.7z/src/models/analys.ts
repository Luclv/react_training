export interface Analysic {
    id: string;
    title: string;
    value: number;
  }
  